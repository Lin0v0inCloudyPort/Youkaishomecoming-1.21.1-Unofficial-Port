package dev.xkmc.fastprojectileapi.collision;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public interface IEntityCache {

	SectionCache get(int x, int y, int z);

	Level level();

	default List<Entity> foreach(AABB aabb, Predicate<Entity> filter) {
		int x0 = (((int) aabb.minX) >> 4) - 1;
		int y0 = (((int) aabb.minY) >> 4) - 1;
		int z0 = (((int) aabb.minZ) >> 4) - 1;
		int x1 = (((int) aabb.maxX) >> 4) + 1;
		int y1 = (((int) aabb.maxY) >> 4) + 1;
		int z1 = (((int) aabb.maxZ) >> 4) + 1;
		long sectionCount = (long) (x1 - x0 + 1) * (y1 - y0 + 1) * (z1 - z0 + 1);
		if (sectionCount > 1000 || sectionCount < 0) {
			return List.of();
		}
		double cx = (aabb.minX + aabb.maxX) * 0.5;
		double cy = (aabb.minY + aabb.maxY) * 0.5;
		double cz = (aabb.minZ + aabb.maxZ) * 0.5;
		double rx = (aabb.maxX - aabb.minX) * 0.5;
		double ry = (aabb.maxY - aabb.minY) * 0.5;
		double rz = (aabb.maxZ - aabb.minZ) * 0.5;
		double maxR = Math.max(rx, Math.max(ry, rz));
		List<Entity> list = new ArrayList<>();
		for (int x = x0; x <= x1; x++) {
			for (int y = y0; y <= y1; y++) {
				for (int z = z0; z <= z1; z++) {
					for (var e : get(x, y, z).intersect(aabb)) {
						var ebox = e.getBoundingBox().expandTowards(e.getDeltaMovement());
						double er = Math.max(ebox.getXsize(), Math.max(ebox.getYsize(), ebox.getZsize())) * 0.5;
						double ecx = (ebox.minX + ebox.maxX) * 0.5;
						double ecy = (ebox.minY + ebox.maxY) * 0.5;
						double ecz = (ebox.minZ + ebox.maxZ) * 0.5;
						double dx = ecx - cx;
						double dy = ecy - cy;
						double dz = ecz - cz;
						double distSqr = dx * dx + dy * dy + dz * dz;
						double threshold = maxR + er;
						if (distSqr > threshold * threshold) continue;
						if (aabb.intersects(ebox) && filter.test(e)) {
							list.add(e);
						}
					}
				}
			}
		}
		for (var e : level().getPartEntities()) {
			var ebox = e.getBoundingBox().expandTowards(e.getDeltaMovement());
			if (aabb.intersects(ebox) && filter.test(e)) {
				list.add(e);
			}
		}
		return list;
	}

}
