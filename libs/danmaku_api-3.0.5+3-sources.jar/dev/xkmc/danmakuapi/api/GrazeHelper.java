package dev.xkmc.danmakuapi.api;

import dev.xkmc.fastprojectileapi.entity.GrazingEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

public class GrazeHelper {

	public static int globalInvulTime = 0;
	public static int globalForbidTime = 0;

	/**
	 * Pluggable provider so downstream mods (e.g. GensokyoLegacy) can inject a full
	 * graze / power / life / bomb system without modifying the danmaku entities or items.
	 * The default implementation keeps the original no-op behaviour.
	 */
	public interface GrazeProvider {

		default void graze(Player entity, GrazingEntity e) {
		}

		default float getHitBoxShrink(Player player) {
			return 0;
		}

		default boolean shouldPlayerHurt(Player player, LivingEntity le) {
			return true;
		}

		default boolean forbidDanmaku(Player player) {
			return false;
		}

	}

	private static GrazeProvider provider = new GrazeProvider() {
	};

	public static void setProvider(GrazeProvider p) {
		provider = p;
	}

	public static void graze(Player entity, GrazingEntity e) {
		provider.graze(entity, e);
	}

	public static float getHitBoxShrink(Player player) {
		return provider.getHitBoxShrink(player);
	}

	public static boolean shouldPlayerHurt(Player player, LivingEntity le) {
		return provider.shouldPlayerHurt(player, le);
	}

	public static boolean forbidDanmaku(Player player) {
		return provider.forbidDanmaku(player);
	}

}
