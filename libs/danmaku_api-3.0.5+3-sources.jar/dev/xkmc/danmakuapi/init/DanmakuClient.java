package dev.xkmc.danmakuapi.init;

import dev.xkmc.danmakuapi.content.particle.DanmakuPoofParticle;
import dev.xkmc.danmakuapi.content.item.DanmakuItemDeco;
import dev.xkmc.danmakuapi.content.item.SpellItem;
import dev.xkmc.danmakuapi.init.registrate.DanmakuItems;
import dev.xkmc.fastprojectileapi.render.ProjectileRenderHelper;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.DyeColor;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.ModelEvent;
import net.neoforged.neoforge.client.event.RegisterItemDecorationsEvent;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;

@EventBusSubscriber(value = Dist.CLIENT, modid = DanmakuAPI.MODID, bus = EventBusSubscriber.Bus.MOD)
public class DanmakuClient {

	@SubscribeEvent
	public static void clientSetup(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			for (var e : DanmakuItems.Bullet.values())
				for (var d : DyeColor.values())
					e.get(d).get().getTypeForRender();
			for (var e : DanmakuItems.Laser.values())
				for (var d : DyeColor.values())
					e.get(d).get().getTypeForRender();
			ProjectileRenderHelper.setup();
		});
	}

	@SubscribeEvent
	public static void registerItemDeco(RegisterItemDecorationsEvent event) {
		var deco = new DanmakuItemDeco();
		for (var col : DyeColor.values()) {
			for (var e : DanmakuItems.Bullet.values()) {
				event.register(e.get(col), deco);
			}
			for (var e : DanmakuItems.Laser.values()) {
				event.register(e.get(col), deco);
			}
		}
		event.register(DanmakuItems.CUSTOM_SPELL_RING.get(), deco);
		event.register(DanmakuItems.CUSTOM_SPELL_HOMING.get(), deco);
		for (var e : SpellItem.LIST) {
			event.register(e, deco);
		}
	}

	@SubscribeEvent
	public static void registerParticle(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(DanmakuItems.POOF.get(), DanmakuPoofParticle.Provider::new);
	}

	@SubscribeEvent
	public static void onModelBake(ModelEvent.ModifyBakingResult event) {
		var models = event.getModels();
		for (var t : DanmakuItems.Bullet.values()) {
			var whiteItem = t.get(DyeColor.WHITE).get();
			var whiteId = BuiltInRegistries.ITEM.getKey(whiteItem);
			var whiteModelLoc = ModelResourceLocation.inventory(whiteId);
			var whiteModel = models.get(whiteModelLoc);
			if (whiteModel == null) continue;
			for (var e : DyeColor.values()) {
				if (e.ordinal() < 16) continue;
				var item = t.get(e).get();
				var id = BuiltInRegistries.ITEM.getKey(item);
				var modelLoc = ModelResourceLocation.inventory(id);
				models.put(modelLoc, whiteModel);
			}
		}
		for (var t : DanmakuItems.Laser.values()) {
			var whiteItem = t.get(DyeColor.WHITE).get();
			var whiteId = BuiltInRegistries.ITEM.getKey(whiteItem);
			var whiteModelLoc = ModelResourceLocation.inventory(whiteId);
			var whiteModel = models.get(whiteModelLoc);
			if (whiteModel == null) continue;
			for (var e : DyeColor.values()) {
				if (e.ordinal() < 16) continue;
				var item = t.get(e).get();
				var id = BuiltInRegistries.ITEM.getKey(item);
				var modelLoc = ModelResourceLocation.inventory(id);
				models.put(modelLoc, whiteModel);
			}
		}
	}

}
